Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.checkInterval)

        local playerPed = PlayerPedId()
        local weapon = GetCurrentPedWeapon(playerPed)

        if not IsPlayerFreeAiming(PlayerId()) and not IsWeaponIgnored(weapon) then
            ApplyDrunkEffect(Config.drunkIntensity)
        end
    end
end)

function IsWeaponIgnored(weapon)
    for _, ignoredWeapon in pairs(Config.ignoredWeapons) do
        if weapon == GetHashKey(ignoredWeapon) then
            return true
        end
    end
    return false
end

function ApplyDrunkEffect(intensity)
    ShakeGameplayCam("DRUNK_SHAKE", intensity)
end