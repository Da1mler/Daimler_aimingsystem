fx_version 'adamant'

game 'gta5'

version '1.0'

author 'da1mleros' -- discord
description 'Daimler_aimingsystem - Realistic aiming system. When player start aiming then it start shaking. Dont work for sinper rifles (you can set guns you dont want to start shaking after aiming in config)'

shared_script 'config.lua'
client_script 'client.lua'