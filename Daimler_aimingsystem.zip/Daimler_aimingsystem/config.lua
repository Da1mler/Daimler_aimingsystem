-- config.lua

Config = {}

-- Drunk effect intensity
Config.drunkIntensity = 0.5

-- Time interval for aiming check
Config.checkInterval = 1000  -- 100 milliseconds

-- Ignored weapons for drunk effect
Config.ignoredWeapons = {
    "WEAPON_UNARMED",
    "WEAPON_KNIFE",
    -- Add more weapons as needed
}
